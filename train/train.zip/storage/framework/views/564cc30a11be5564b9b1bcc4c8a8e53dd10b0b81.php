<div data-am-widget="slider" class="am-slider am-slider-a1" data-am-slider='{"directionNav":false}' >
    <ul class="am-slides">
        <li>
            <img src="<?php echo e(asset('/img/mobile/ban3.jpg')); ?>">
            <div class="pet_slider_font">
                <span class="pet_slider_emoji"> (╭￣3￣)╭♡   </span>
                <span>快上爱旅分途吧</span>
            </div>
            <div class="pet_slider_shadow"></div>
        </li>
        <li>
            <img src="<?php echo e(asset('/img/mobile/ban2.jpg')); ?>">
            <div class="pet_slider_font">
                <span class="pet_slider_emoji"> []~(￣▽￣)~*　</span>
                <span>爱旅分途多重惊喜等你来拿</span>
            </div>
            <div class="pet_slider_shadow"></div>
        </li>
        <li>
            <img src="<?php echo e(asset('/img/mobile/ban3.jpg')); ?>">
            <div class="pet_slider_font">
                <span class="pet_slider_emoji"> (｡・`ω´･)　</span>
                <span>与您相约爱旅分途，不见不散哦。。。。</span>
            </div>
            <div class="pet_slider_shadow"></div>
        </li>
    </ul>
</div>
