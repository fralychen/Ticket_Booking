<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body id="app-layout">
    <?php echo $__env->make("partials.top", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make("partials.header", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make("partials.nav", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <!-- JavaScripts -->
</body>
</html>
