<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/personalcenter/css/font-awesome.css')); ?>" type="text/css" />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/doubleDate.css')); ?>"/>
    <script src="<?php echo e(asset('js/jquery-1.4.2.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/doubleDate2.0.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <title>首页</title>
</head>