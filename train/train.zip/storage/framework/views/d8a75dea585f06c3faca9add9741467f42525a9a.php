<div class="row">
        <div class="nav">
            <a class="active" href="http://www.alvft.com/">&nbsp;首页&nbsp;</a>
            <a  href="http://www.alvft.com/index.php?s=/Home/Abroad/index" target="_blank" >出境游<i></i></a>
            <a  href="http://www.alvft.com/index.php?s=/Home/Scenic/index/aid/3.htm" target="_blank" >国内游<i></i></a>
            <a  href="http://www.alvft.com/index.php?s=/Home/Scenic/index/aid/4.htm" target="_blank" >周边游<i></i></a>
            <a  href="http://www.alvft.com/index.php?s=/Home/Scenic/index/aid/5.htm" target="_blank" >当地游<i></i></a>
            <a  href="<?php echo e(asset('/')); ?>" target="_blank" >火车票务<i></i></a>
            <a  href="http://www.alvft.com/index.php?s=/Home/Service/hotel" target="_blank" >酒店预定<i></i></a>
            <a  href="http://www.alvft.com/index.php?s=/Home/Service/aircraft" target="_blank" >飞机票务<i></i></a>

            <a  href="http://www.alvft.com/index.php?s=/Home/Service/show" target="_blank" >演出票务<i></i></a>
            <a  href="http://www.alvft.com/index.php?s=/Home/Service/life" target="_blank" >生活社区<i></i></a>
            <a href="http://www.alvft.com/index.php?s=/Member/Custom/index" target="_blank" >个人定制<i></i></a>
        </div>
</div>
