@extends('layouts.app')

@section('content')
    <link rel="stylesheet" href="{{asset('/css/mycss/home.css')}}">
    <div class="container">
        <div class="row">
            <h1 class="text-center">出票失败</h1>
        </div>
    </div>
@endsection