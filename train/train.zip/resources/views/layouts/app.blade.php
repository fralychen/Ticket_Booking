<!DOCTYPE html>
<html lang="en">
@include('partials.head')
<body id="app-layout">
    @include("partials.top")
    @include("partials.header")
    @include("partials.nav")
    @yield('content')
    <!-- JavaScripts -->
</body>
</html>
