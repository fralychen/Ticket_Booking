<!DOCTYPE html>
<html lang="en">
@include('partials.head')
<body id="app-layout">
    @yield('content')
</body>
</html>
