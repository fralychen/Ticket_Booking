<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>退票</title>
    @include('partials.user.head')
</head>
<body>
<div  id="wrapper">
    <!-- navbar -->
@include('partials.user.header')
@include('partials.user.border')
@include('partials.user.refund')
    <!-- footer -->
@include('partials.user.footer')
<!-- / footer -->
</div>
</body>
</html>