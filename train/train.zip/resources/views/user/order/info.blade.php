<!DOCTYPE html>
<html lang="en">
<head>
    <title>订单详情</title>
    @include('partials.user.head')
</head>
<body>
<div id="wrapper">
@include('partials.user.header')
@include('partials.user.border')
@include('partials.user.contentinfo')
@include('partials.user.footer')
</div>
</body>
</html>
