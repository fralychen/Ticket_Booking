<!--footer-->
<footer data-am-widget="footer"
        class="am-footer am-footer-default"
        data-am-footer="{  }">
    <div class="am-footer-miscs ">
        <p>由 <!--<a href="#" title="博文优创"
                    target="_blank" class="">博文优创</a>-->博文优创
            提供技术支持</p>
        <p>CopyRight©2014  AllMobilize Inc.</p>
        <p>京ICP备13033158</p>
    </div>
</footer>