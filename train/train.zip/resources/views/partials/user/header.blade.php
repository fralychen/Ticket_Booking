<nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                <span class="sr-only">退出</span>
               <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="{{asset('/')}}">用户中心</a>
        </div>
        <div class="header-right">
            <a href="{{asset('/')}}" class="btn btn-danger" title="Logout">退出<i class="fa fa-exclamation-circle fa-2x"></i></a>
        </div>
    </nav>
