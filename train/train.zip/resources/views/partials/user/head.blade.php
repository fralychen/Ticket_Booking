<meta name="description" content="app, web app, responsive, responsive layout, admin, admin panel, admin dashboard, flat, flat ui, ui kit, AngularJS, ui route, charts, widgets, components" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="{{asset('css/personalcenter/css/bootstrap.css')}}" type="text/css" />
<link rel="stylesheet" href="{{asset('css/personalcenter/css/font-awesome.css')}}" type="text/css" />
<link rel="stylesheet" href="{{asset('css/personalcenter/css/basic.css')}}" type="text/css" />
<link rel="stylesheet" href="{{asset('css/personalcenter/css/custom.css')}}" type="text/css" />
<link rel="stylesheet" href="{{asset('http://fonts.googleapis.com/css?family=Open+Sans')}}" type="text/css" />
<script src="{{asset('css/personalcenter/js/jquery-1.10.2.js')}}"></script>
<script src="{{asset('css/personalcenter/js/bootstrap.js')}}"></script>
<script src="{{asset('css/personalcenter/js/jquery.metisMenu.js')}}"></script>
<script src="{{asset('css/personalcenter/js/custom.js')}}"></script>