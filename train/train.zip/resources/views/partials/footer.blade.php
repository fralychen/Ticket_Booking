
    <div class="footer">
        <div class="clear"></div>
        <div class="btm_nav">
            <a href="http://www.alvft.com/index.php?s=/Home/Page/about/aid/1.htm" target="_blank">关于我们</a><a href="http://www.alvft.com/index.php?s=/Home/Page/about/aid/2.htm" target="_blank">联系我们</a>
            <a href="http://www.alvft.com/index.php?s=/Home/Page/about/aid/2.htm" target="_blank">旅游资质</a><a href="http://www.alvft.com/index.php?s=/Home/Page/about/aid/7.htm" target="_blank">免责声明</a>
        </div>
        <div class="btm_info">

            <p class="ba">
                Copyright&nbsp;©&nbsp;2015-2016&nbsp;&nbsp;版权所有&nbsp;&nbsp;
                <a href="http://www.alvft.com/" target="_blank">爱旅纷途旅游网</a> &nbsp;&nbsp;&nbsp;&nbsp;鄂ICP备16022333号-1<br/> 热线电话：400-8079798 <i class="website_telphone"></i>
                <br />
                <i id="bqlogo"><a href="http://alft.kuqiw.com" target="_blank">技术支持：博文优创</a></i>
            </p>
        </div>
    </div>


