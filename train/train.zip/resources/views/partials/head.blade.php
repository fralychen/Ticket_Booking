<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}"/>
    <link rel="stylesheet" href="{{asset('css/personalcenter/css/font-awesome.css')}}" type="text/css" />
    <link type="text/css" rel="stylesheet" href="{{asset('css/doubleDate.css')}}"/>
    <script src="{{asset('js/jquery-1.4.2.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/doubleDate2.0.js')}}"></script>
    <script src="{{asset('js/bootstrap.min.js')}}"></script>
    <title>首页</title>
</head>