<style>
    .header {padding:20px 0;}
    .header .logo { width:330px; height:70px; float: left; }
    .header .logo img{margin-left:50%;}
</style>
<div class="header">
<div class="logo"><a href="{{ url('/') }}" title="爱旅纷途旅游网">
        <img src="{{asset('/img/logo.png')}}" alt="爱旅纷途旅游网"></a>
</div>
</div>