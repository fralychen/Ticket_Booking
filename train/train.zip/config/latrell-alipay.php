<?php
return [

	//合作身份者id，以2088开头的16位纯数字。
	'partner_id' => '2088521334181495',

	//卖家支付宝帐户。
	'seller_id' => 'pay@alvft.com'
];
