<?php

namespace App\Http\Controllers\User\Order;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class SureController extends Controller
{
    public function index(Request $request)
    {



    }
}
