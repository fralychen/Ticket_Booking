<?php

namespace App\Http\Controllers\Refund;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class ReturnController extends Controller
{
    //
}
