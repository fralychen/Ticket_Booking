<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrainsOrder extends Model
{
    protected $table = "payment_order";

    protected $primaryKey = "order_id";
}
