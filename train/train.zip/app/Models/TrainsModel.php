<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrainsModel extends Model
{
    //
    protected $table = 'trains';

    public $primaryKey = 'id';
}
