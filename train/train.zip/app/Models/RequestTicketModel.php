<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RequestTicketModel extends Model
{

    protected $table = 'request_ticket';
    public $primaryKey = 'order_id';

   

}
