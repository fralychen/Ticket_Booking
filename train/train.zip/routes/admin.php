<?php
/**
 * Created by PhpStorm.
 * User: alvft
<<<<<<< HEAD
 * Date: 2017/4/15
 * Time: 13:40
 */

Route::group(['middleware' => 'web'], function () {

});